'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'

export function YordamBot() {
  const [messages, setMessages] = useState<string[]>([])
  const [newMessage, setNewMessage] = useState('')

  useEffect(() => {
    const storedMessages = localStorage.getItem('yordamBotMessages')
    if (storedMessages) {
      setMessages(JSON.parse(storedMessages))
    }
  }, [])

  useEffect(() => {
    localStorage.setItem('yordamBotMessages', JSON.stringify(messages))
  }, [messages])

  const handleAddMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim()) return

    setMessages([...messages, newMessage])
    setNewMessage('')
  }

  const handleDeleteMessage = (index: number) => {
    const newMessages = messages.filter((_, i) => i !== index)
    setMessages(newMessages)
  }

  const handleUpdateMessage = (index: number, updatedMessage: string) => {
    const newMessages = [...messages]
    newMessages[index] = updatedMessage
    setMessages(newMessages)
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <h2 className="text-2xl font-bold">YordamBot Xabarlari</h2>

      <form onSubmit={handleAddMessage} className="space-y-4">
        <Textarea
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Yangi xabar kiriting"
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
        />
        <Button type="submit" className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-bold py-2 rounded-full transition-all duration-300 transform hover:scale-105">
          Xabar qo'shish
        </Button>
      </form>

      <div className="space-y-4">
        {messages.map((message, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="flex items-center space-x-2 bg-gray-100 p-3 rounded-lg"
          >
            <Input
              value={message}
              onChange={(e) => handleUpdateMessage(index, e.target.value)}
              className="flex-grow"
            />
            <Button
              onClick={() => handleDeleteMessage(index)}
              variant="destructive"
              className="bg-red-500 hover:bg-red-600 text-white font-bold py-1 px-3 rounded-full transition-all duration-300 transform hover:scale-105"
            >
              O'chirish
            </Button>
          </motion.div>
        ))}
      </div>

      <Button
        onClick={() => alert('Barcha o\'zgarishlar saqlandi!')}
        className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-2 rounded-full transition-all duration-300 transform hover:scale-105"
      >
        Tasdiqlash
      </Button>
    </motion.div>
  )
}

