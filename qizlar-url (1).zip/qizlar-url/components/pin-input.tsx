'use client'

import React, { useRef, useEffect } from 'react'
import { Input } from '@/components/ui/input'

interface PinInputProps {
  value: string
  onChange: (value: string) => void
  onComplete?: () => void
  length?: number
}

export function PinInput({ value, onChange, onComplete, length = 4 }: PinInputProps) {
  const inputRefs = useRef<HTMLInputElement[]>([])

  useEffect(() => {
    if (value.length === length && onComplete) {
      onComplete()
    }
  }, [value, length, onComplete])

  const handleChange = (index: number, digit: string) => {
    if (digit.length > 1) return

    const newValue = value.split('')
    newValue[index] = digit
    onChange(newValue.join(''))

    if (digit && index < length - 1) {
      inputRefs.current[index + 1]?.focus()
    }
  }

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !value[index] && index > 0) {
      inputRefs.current[index - 1]?.focus()
    }
  }

  return (
    <div className="flex justify-center space-x-2">
      {Array.from({ length }).map((_, index) => (
        <Input
          key={index}
          type="text"
          inputMode="numeric"
          pattern="[0-9]*"
          maxLength={1}
          value={value[index] || ''}
          onChange={(e) => handleChange(index, e.target.value)}
          onKeyDown={(e) => handleKeyDown(index, e)}
          ref={(el) => el && (inputRefs.current[index] = el)}
          className="w-12 h-12 text-center text-2xl rounded-lg border-2 border-gray-300 focus:border-purple-500 focus:ring focus:ring-purple-200 transition-all"
        />
      ))}
    </div>
  )
}

