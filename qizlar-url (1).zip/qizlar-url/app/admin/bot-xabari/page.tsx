'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { toast } from 'sonner'

export default function BotXabariPage() {
  const [yordamBotMessages, setYordamBotMessages] = useState<string[]>([])
  const [tanishuvBotMessages, setTanishuvBotMessages] = useState<string[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [activeBot, setActiveBot] = useState<'yordam' | 'tanishuv'>('yordam')

  useEffect(() => {
    const storedYordamMessages = localStorage.getItem('yordamBotMessages')
    const storedTanishuvMessages = localStorage.getItem('tanishuvBotMessages')
    if (storedYordamMessages) setYordamBotMessages(JSON.parse(storedYordamMessages))
    if (storedTanishuvMessages) setTanishuvBotMessages(JSON.parse(storedTanishuvMessages))
  }, [])

  useEffect(() => {
    localStorage.setItem('yordamBotMessages', JSON.stringify(yordamBotMessages))
    localStorage.setItem('tanishuvBotMessages', JSON.stringify(tanishuvBotMessages))
  }, [yordamBotMessages, tanishuvBotMessages])

  const handleAddMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim()) return

    if (activeBot === 'yordam') {
      setYordamBotMessages([...yordamBotMessages, newMessage])
    } else {
      setTanishuvBotMessages([...tanishuvBotMessages, newMessage])
    }
    setNewMessage('')
    toast.success('Xabar muvaffaqiyatli qo\'shildi!')
  }

  const handleDeleteMessage = (index: number) => {
    if (activeBot === 'yordam') {
      setYordamBotMessages(yordamBotMessages.filter((_, i) => i !== index))
    } else {
      setTanishuvBotMessages(tanishuvBotMessages.filter((_, i) => i !== index))
    }
    toast.success('Xabar muvaffaqiyatli o\'chirildi!')
  }

  const handleUpdateMessage = (index: number, updatedMessage: string) => {
    if (activeBot === 'yordam') {
      const newMessages = [...yordamBotMessages]
      newMessages[index] = updatedMessage
      setYordamBotMessages(newMessages)
    } else {
      const newMessages = [...tanishuvBotMessages]
      newMessages[index] = updatedMessage
      setTanishuvBotMessages(newMessages)
    }
    toast.success('Xabar muvaffaqiyatli yangilandi!')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-400 via-purple-400 to-indigo-400 flex flex-col items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-2xl bg-white/90 backdrop-blur-lg rounded-3xl shadow-2xl p-8 space-y-8"
      >
        <h1 className="text-4xl font-bold text-center text-gray-800">
          Bot Xabarlari Boshqaruvi
        </h1>

        <div className="flex space-x-4">
          <Button
            onClick={() => setActiveBot('yordam')}
            className={`flex-1 ${activeBot === 'yordam' ? 'bg-purple-600' : 'bg-gray-300'} text-white font-bold py-2 rounded-full transition-all duration-300`}
          >
            YordamBot
          </Button>
          <Button
            onClick={() => setActiveBot('tanishuv')}
            className={`flex-1 ${activeBot === 'tanishuv' ? 'bg-purple-600' : 'bg-gray-300'} text-white font-bold py-2 rounded-full transition-all duration-300`}
          >
            TanishuvBot
          </Button>
        </div>

        <form onSubmit={handleAddMessage} className="space-y-4">
          <Textarea
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Yangi xabar kiriting"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
          <Button 
            type="submit"
            className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-bold py-2 rounded-full transition-all duration-300 transform hover:scale-105"
          >
            Xabar qo'shish
          </Button>
        </form>

        <div className="space-y-4">
          <h2 className="text-2xl font-bold text-gray-800">Mavjud xabarlar:</h2>
          {(activeBot === 'yordam' ? yordamBotMessages : tanishuvBotMessages).map((message, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex items-center space-x-2 bg-gray-100 p-3 rounded-lg"
            >
              <Input
                value={message}
                onChange={(e) => handleUpdateMessage(index, e.target.value)}
                className="flex-grow"
              />
              <Button
                onClick={() => handleDeleteMessage(index)}
                variant="destructive"
                className="bg-red-500 hover:bg-red-600 text-white font-bold py-1 px-3 rounded-full transition-all duration-300 transform hover:scale-105"
              >
                O'chirish
              </Button>
            </motion.div>
          ))}
        </div>

        <Button
          onClick={() => {
            localStorage.setItem('yordamBotMessages', JSON.stringify(yordamBotMessages))
            localStorage.setItem('tanishuvBotMessages', JSON.stringify(tanishuvBotMessages))
            toast.success('Barcha o\'zgarishlar saqlandi!')
          }}
          className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-2 rounded-full transition-all duration-300 transform hover:scale-105"
        >
          Tasdiqlash
        </Button>
      </motion.div>
    </div>
  )
}

