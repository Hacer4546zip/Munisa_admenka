'use client'

import { TanishuvBot } from '@/components/tanishuv-bot'

export default function TanishuvBotPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-400 via-purple-400 to-indigo-400 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-white/90 backdrop-blur-lg rounded-3xl shadow-2xl p-8 space-y-8">
        <h1 className="text-4xl font-bold text-center text-gray-800">
          TanishuvBot Boshqaruvi
        </h1>
        <TanishuvBot />
      </div>
    </div>
  )
}

