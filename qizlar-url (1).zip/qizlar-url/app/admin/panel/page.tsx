'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

export default function AdminPanel() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-400 via-purple-400 to-indigo-400 flex flex-col items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-2xl bg-white/90 backdrop-blur-lg rounded-3xl shadow-2xl p-8 space-y-8"
      >
        <h1 className="text-4xl font-bold text-center text-gray-800">
          Admin Panel
        </h1>

        <div className="space-y-4">
          <Link href="/admin/lenk-uzb">
            <Button className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-bold py-3 rounded-full transition-all duration-300 transform hover:scale-105">
              Lenkuz
            </Button>
          </Link>
          <Link href="/admin/bot-xabari">
            <Button className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-bold py-3 rounded-full transition-all duration-300 transform hover:scale-105">
              Bot xabari
            </Button>
          </Link>
        </div>
      </motion.div>
    </div>
  )
}

