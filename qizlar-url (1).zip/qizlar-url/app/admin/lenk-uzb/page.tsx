'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { toast } from 'sonner'

export default function LenkUzbPage() {
  const [urls, setUrls] = useState<string[]>([])
  const [newUrl, setNewUrl] = useState('')

  useEffect(() => {
    const storedUrls = localStorage.getItem('qizlarURL')
    if (storedUrls) {
      setUrls(JSON.parse(storedUrls))
    }
  }, [])

  useEffect(() => {
    localStorage.setItem('qizlarURL', JSON.stringify(urls))
  }, [urls])

  const handleAddUrl = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newUrl.trim()) return

    const formattedUrl = `https://t.me/${newUrl.replace(/^https?:\/\/(t\.me\/)?/, '')}`
    setUrls([...urls, formattedUrl])
    setNewUrl('')
    toast.success('URL muvaffaqiyatli qo\'shildi!')
  }

  const handleDeleteUrl = (index: number) => {
    const newUrls = urls.filter((_, i) => i !== index)
    setUrls(newUrls)
    toast.success('URL muvaffaqiyatli o\'chirildi!')
  }

  const handleUpdateUrl = (index: number, updatedUrl: string) => {
    const newUrls = [...urls]
    newUrls[index] = `https://t.me/${updatedUrl.replace(/^https?:\/\/(t\.me\/)?/, '')}`
    setUrls(newUrls)
    toast.success('URL muvaffaqiyatli yangilandi!')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-400 via-purple-400 to-indigo-400 flex flex-col items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-2xl bg-white/90 backdrop-blur-lg rounded-3xl shadow-2xl p-8 space-y-8"
      >
        <h1 className="text-4xl font-bold text-center text-gray-800">
          Lenkuz - URL Boshqaruvi
        </h1>

        <form onSubmit={handleAddUrl} className="space-y-4">
          <Input
            type="text"
            value={newUrl}
            onChange={(e) => setNewUrl(e.target.value)}
            placeholder="Yangi URL kiriting (misol: username yoki https://t.me/username)"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
          <Button 
            type="submit"
            className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-bold py-2 rounded-full transition-all duration-300 transform hover:scale-105"
          >
            URL qo'shish
          </Button>
        </form>

        <div className="space-y-4">
          <h2 className="text-2xl font-bold text-gray-800">Mavjud URL manzillar:</h2>
          {urls.map((url, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex items-center space-x-2 bg-gray-100 p-3 rounded-lg"
            >
              <Input
                value={url.replace('https://t.me/', '')}
                onChange={(e) => handleUpdateUrl(index, e.target.value)}
                className="flex-grow"
              />
              <Button
                onClick={() => handleDeleteUrl(index)}
                variant="destructive"
                className="bg-red-500 hover:bg-red-600 text-white font-bold py-1 px-3 rounded-full transition-all duration-300 transform hover:scale-105"
              >
                O'chirish
              </Button>
            </motion.div>
          ))}
        </div>

        <Button
          onClick={() => {
            localStorage.setItem('qizlarURL', JSON.stringify(urls))
            toast.success('Barcha o\'zgarishlar saqlandi!')
          }}
          className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-2 rounded-full transition-all duration-300 transform hover:scale-105"
        >
          Tasdiqlash
        </Button>
      </motion.div>
    </div>
  )
}

