'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { YordamChat } from '@/components/yordam-chat'
import { toast } from 'sonner'

export default function LinkUzatish() {
  const [randomUrl, setRandomUrl] = useState('')

  useEffect(() => {
    const urls = JSON.parse(localStorage.getItem('qizlarURL') || '[]')
    if (urls.length > 0) {
      setRandomUrl(urls[Math.floor(Math.random() * urls.length)])
    }
  }, [])

  const handleButtonClick = () => {
    if (randomUrl) {
      window.open(randomUrl, '_blank')
      toast.success('Qizga xabar yozish uchun yo\'naltirilmoqdasiz!')
    } else {
      toast.error('URL topilmadi. Iltimos, admin panelida URL qo\'shing.')
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-400 via-purple-400 to-indigo-400 flex flex-col items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md bg-white/90 backdrop-blur-lg rounded-3xl shadow-2xl p-8 space-y-8"
      >
        <h1 className="text-4xl font-bold text-center text-gray-800">
          Link Uzatish
        </h1>
        
        <p className="text-center text-gray-600">
          Salom! Xush kelibsiz.
        </p>

        <Button 
          onClick={handleButtonClick}
          className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-bold py-3 rounded-full transition-all duration-300 transform hover:scale-105"
        >
          Qizga xabar yozish
        </Button>

        <YordamChat />
      </motion.div>
    </div>
  )
}

