'use server'

import { supabase } from '@/lib/supabase'

// URL-lar uchun funktsiyalar
export async function getUrls() {
  const { data, error } = await supabase.from('urls').select('*')
  if (error) throw error
  return data
}

export async function addUrl(url: string) {
  const { data, error } = await supabase.from('urls').insert({ url }).select()
  if (error) throw error
  return data[0]
}

export async function updateUrl(id: number, url: string) {
  const { data, error } = await supabase.from('urls').update({ url }).eq('id', id).select()
  if (error) throw error
  return data[0]
}

export async function deleteUrl(id: number) {
  const { error } = await supabase.from('urls').delete().eq('id', id)
  if (error) throw error
}

// Bot xabarlari uchun funktsiyalar
export async function getBotMessages(botType: 'yordam' | 'tanishuv') {
  const table = botType === 'yordam' ? 'yordam_bot_messages' : 'tanishuv_bot_messages'
  const { data, error } = await supabase.from(table).select('*')
  if (error) throw error
  return data
}

export async function addBotMessage(botType: 'yordam' | 'tanishuv', message: string) {
  const table = botType === 'yordam' ? 'yordam_bot_messages' : 'tanishuv_bot_messages'
  const { data, error } = await supabase.from(table).insert({ message }).select()
  if (error) throw error
  return data[0]
}

export async function updateBotMessage(botType: 'yordam' | 'tanishuv', id: number, message: string) {
  const table = botType === 'yordam' ? 'yordam_bot_messages' : 'tanishuv_bot_messages'
  const { data, error } = await supabase.from(table).update({ message }).eq('id', id).select()
  if (error) throw error
  return data[0]
}

export async function deleteBotMessage(botType: 'yordam' | 'tanishuv', id: number) {
  const table = botType === 'yordam' ? 'yordam_bot_messages' : 'tanishuv_bot_messages'
  const { error } = await supabase.from(table).delete().eq('id', id)
  if (error) throw error
}

