'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { PinInput } from '@/components/pin-input'
import { AdminPanel } from '@/components/admin-panel'
import { OnlineChat } from '@/components/online-chat'
import { toast } from 'sonner'

export default function Bosh_sahifa() {
  const router = useRouter()
  const [pin, setPin] = useState('')
  const validPins = ['760', '769', '6622', '6287']

  const handlePinSubmit = () => {
    if (validPins.includes(pin)) {
      router.push('/link-uzatish')
    } else {
      toast.error('Kod xato terildi, qayta urinib ko\'ring.')
      setPin('')
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-400 via-purple-400 to-indigo-400 flex flex-col items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md bg-white/90 backdrop-blur-lg rounded-3xl shadow-2xl p-8 space-y-8"
      >
        <h1 className="text-4xl font-bold text-center text-gray-800">
          Bosh Sahifa
        </h1>
        
        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700 block text-center">
              PIN Kodni kiriting
            </label>
            <PinInput
              value={pin}
              onChange={setPin}
              onComplete={handlePinSubmit}
              length={4}
            />
          </div>

          <Button 
            onClick={handlePinSubmit}
            className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-bold py-3 rounded-full transition-all duration-300 transform hover:scale-105"
          >
            Tasdiqlash
          </Button>

          <AdminPanel />
        </div>
      </motion.div>

      <div className="mt-8 w-full max-w-md">
        <OnlineChat />
      </div>
    </div>
  )
}

